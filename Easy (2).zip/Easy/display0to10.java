import java.lang.*;

class display0to10
{
	public static void main(String args[])
	{
		int i=1;
		for(i=0;i<=10;i++)
		{
			System.out.println(i);
		}
		
		
	}
}