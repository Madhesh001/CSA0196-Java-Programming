import java.lang.*;
import java.util.Scanner;

class prime
{
	public static void main(String args[])
	{
		int i,count=1;
		Scanner in = new Scanner(System.in);
		System.out.println("enter the number:");
		int n = in.nextInt();
		for(i=2;i<=n;i++)
		{
			if(n%i==0)
			{
				count++;
			}
		}
		if(count==2)
		{
		System.out.print(n+" is a prime number");
		}
		else
		{
		System.out.print(n+" is a composite number");
		}
		
	}
}